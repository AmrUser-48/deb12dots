" Optionst {{{
" check if we have the lastest stable version of nvim
"if !has('nvim-0.7.0')
  "echohl Error | echomsg "Nvim 0.7.0 required, but is missing!" | echohl None
  "finish
"endif


" Extegnal program to use for grep command
"" Зовнішня програма для використання команди grep
if executable('rg')
  set grepprg=rg\ --vimgrep\ --no-heading\ --smart-case
  set grepformat=%f:%l:%c:%m
endif


" Ignore certain files and folders when globing
set wildignore+=*.o,*.obj,*.dylib,*.bin,*.dll,*.exe
set wildignore+=*/.git/*,*/.svn/*,*/__pycache__/*,*/build/**
set wildignore+=*.jpg,*.png,*.jpeg,*.bmp,*.gif,*.tiff,*.svg,*.ico
set wildignore+=*.pyc,*.pkl
set wildignore+=*.DS_Store
set wildignore+=*.aux,*.bbl,*.blg,*.brf,*.fls,*.fdb_latexmk,*.synctex.gz,*.xdv
set wildignorecase  " ignore file and dir name cases in cmd-completion

" change fillchars for folding, vertical split, end of buffer, and message separator
set fillchars=fold:\ ,vert:\│,eob:\ ,msgsep:‾

" Paste mode toggle, it seems that Nvim's bracketed paste mode
" does not work very well for nvim-qt, so we use good-old paste mode
set pastetoggle=<F12>

" Split window below/right when creating horizontal/vertical windows
set splitbelow splitright


" Use list mode and customized listchars
"set listchars=tab:▸\ ,extends:❯,precedes:❮,nbsp:
set listchars=tab:>\ ,space:·,extends:>,precedes:<,nbsp:␣,trail:•,eol:¬ 
"    set lcs=tab:>-,trail:-


" General tab settings
set tabstop=4       " number of visual spaces per TAB
set softtabstop=4   " number of spaces in tab when editing
set shiftwidth=4    " number of spaces to use for autoindent
set expandtab       " expand tab to spaces so that tabs are spaces
set visualbell noerrorbells  " Do not use visual and errorbells

" Set matching pairs of characters and highlight matching brackets
set matchpairs+=<:>,「:」,『:』,【:】,“:”,‘:’,《:》

"set number relativenumber  " Show line number and relative line number

" List all matches and complete till longest common string
"set wildmode=list:longest

" Use mouse to select and resize windows, etc.
"set mouse=nic  " Enable mouse in several mode
set mouse=a
"set mousemodel=popup  " Set the behaviour of mouse

" Ignore case in general, but become case-sensitive when uppercase is present
set ignorecase smartcase
"}}}

" Global {{{

" Disable perl provider
let g:loaded_perl_provider = 0

" Disable ruby provider
let g:loaded_ruby_provider = 0

" Disable node provider
let g:loaded_node_provider = 0

"let g:python3_host_prog = '/usr/bin/python3.8'

let g:loaded_python3_provider = 0

let g:did_install_default_menus = 1  " do not load menu

" Enable highlighting for lua HERE doc inside vim script
let g:vimsyn_embed = 'l'


" obsolete
" use filetype.lua instead of filetype.vim
"let g:do_filetype_lua = 1
"let g:did_load_filetypes = 0

filetype plugin indent on



"{{{ Disable loading certain plugins
" Whether to load netrw by default, see
" https://github.com/bling/dotvim/issues/4
let g:loaded_netrw       = 1
let g:loaded_netrwPlugin = 1
let g:netrw_liststyle = 3

" Do not load tohtml.vim
let g:loaded_2html_plugin = 1

" Do not load zipPlugin.vim, gzip.vim and tarPlugin.vim (all these plugins are
" related to checking files inside compressed files)
"let g:loaded_zipPlugin = 1
"let loaded_gzip = 1
"let g:loaded_tarPlugin = 1

let g:loaded_tutor_mode_plugin = 1  " do not load the tutor plugin

" Do not use builtin matchit.vim and matchparen.vim since we use vim-matchup
let g:loaded_matchit = 1
let g:loaded_matchparen = 1
"}}}

"}}}


"" Functions (copypasted) {{{
augroup highlight_yank
  autocmd!
  autocmd TextYankPost * silent! lua require'vim.highlight'.on_yank({ higroup = "Substitute", timeout = 400, on_macro = true })
augroup END


" KEYMAPS {{{
let mapleader=' '

" Shortcut for faster save and quit
nnoremap <silent> <leader>w :<C-U>update<CR>
" Saves the file if modified and quit
nnoremap <silent> <leader>q :<C-U>x<CR>
" Quit all opened buffers
nnoremap <silent> <leader>Q :<C-U>qa!<CR>
" Buffers
nnoremap <silent> <leader>[ :<C-U>bp<CR>
nnoremap <silent> <leader>] :<C-U>bn<CR>

nnoremap <silent> <leader>l :<C-U>set list!<CR>

nnoremap <leader>n :set invnumber invrelativenumber<CR>

map <silent> <F2> <Esc>:update <CR>
imap <silent> <F2> <Esc>:update <CR>

map	 <F3> <Esc>ZQ
imap <F3> <C-O>ZQ

imap	<C-k> <Esc>
imap	kk <Esc>
imap    jj <C-O>

" CMD {{{
nnoremap ; :
xnoremap ; :
map <C-Up> :<C-F>
"}}}

" Clipboard
nnoremap <leader>p "+p
nnoremap <leader>y "+y
vnoremap <leader>p "+p
vnoremap <leader>y "+y

"nnoremap x "_x

" CopyPasting from github/gdhao
" Change text without putting it into the vim register,
" see https://stackoverflow.com/q/54255/6064933
nnoremap c "_c
nnoremap C "_C
nnoremap cc "_cc
xnoremap c "_c

" make X behave like d without adding removed data to a register
"nnoremap X "_d
"nnoremap XX "_dd
"vnoremap X "_d
"vnoremap x "_d
"nnoremap x "_d

" Replace visual selection with text in register, but not contaminate the
" register, see also https://stackoverflow.com/q/10723700/6064933.
xnoremap p "_c<ESC>p

" Do not move my cursor when joining lines.
nnoremap J mzJ`z

" Keep cursor position after yanking
nnoremap y myy
xnoremap y myy

augroup restore_after_yank
  autocmd!
  autocmd TextYankPost *  call s:restore_cursor()
augroup END

function! s:restore_cursor() abort
  silent! normal `y
  silent! delmarks y
endfunction

" TABS {{{
map <leader>t :tabnew<CR>
map	<C-PageUp> gT
map	<C-PageDown> gt
nnoremap <Tab> gt
"}}}


" WINDOWS {{{
nnoremap <Right>	<C-w>l
nnoremap <Left>	<C-w>h
nnoremap <Down>	<C-w>j
nnoremap <Up>	<C-w>k
"innoremap <Right>	<C-o><C-w>l
"innoremap <Left>		<C-o><C-w>h
"innoremap <Down>		<C-o><C-w>j
"innoremap <Up>		<C-o><C-w>k
nnoremap <leader>q	ZQ
nnoremap <leader>s	<C-w>s
nnoremap <leader>v	<C-w>v
nnoremap <leader>c	<C-w>c
"}}} 
"}}} 


" General  {{{
" JUMP to last position in file
if has("autocmd")
  au BufReadPost * if line("'\"") > 1 && line("'\"") <= line("$") | exe "normal! g'\"" | endif
endif

set ts=4                " Tab size
set showmatch           " Show matching brackets.
set ignorecase          " Do case insensitive matching
set smartcase           " Do smart case matching
set incsearch           " Incremental search
set history=10000		" History size
set nonumber              " Line Numbers
set wrap                " Wrap long lines
set noshowcmd           " Dont show cmd please

"}}}


" Lua's {{{
lua require('alpha-nvim')
"lua require('alpha')
"lua require('solarized')
"lua require('lualine').setup()
" lspconfig plugin  :todo 
""lua require'lspconfig'.pyright.setup{}
"lua require("toggleterm").setup()
"lua require('nvim-tree')

"lua << EOF
"require('lualine').setup({
    "options = { theme  = 'solarized_dark' },
    "})
"EOF
"
" Lualine {{{
lua << EOF
-- init.lua
vim.api.nvim_create_user_command('W', function()
  local file = vim.fn.expand('%:p') -- Full path

  -- 1. Try normal write first (works if you own the file or have perms)
  local ok, err = pcall(vim.cmd, 'silent write')
  if ok then
    vim.notify("Saved: " .. file, vim.log.levels.INFO)
    return
  end

  -- 2. Fallback: Check if error is permission related
  -- (E502: Permission denied, E212: Can't open file for writing, etc.)
  if err and (err:match("E502") or err:match("E212") or err:match("Permission denied")) then
    vim.notify("Permission denied. Attempting sudo save...", vim.log.levels.WARN)

    -- Use 'tee' with sudo.
    -- 'shellescape' handles spaces/special chars in filename safely.
    -- 'silent !' runs the command without hitting "Press Enter" prompt.
    -- 'checktime' forces nvim to reload the buffer from disk immediately.
    local cmd = string.format("silent !sudo tee %s > /dev/null", vim.fn.shellescape(file))
    vim.cmd(cmd)
    vim.cmd('checktime') -- Reload buffer silently
    vim.notify("Saved via sudo: " .. file, vim.log.levels.INFO)
  else
    -- 3. Some other error (disk full, readonly fs, etc.) -> show original error
    vim.notify("Save failed: " .. err, vim.log.levels.ERROR)
  end
end, { desc = "Smart Save (auto-sudo if needed)" })

-- Optional: Keymap (Leader + W)
vim.keymap.set('n', '<leader>2', ':W<CR>', { desc = "Smart Save (Sudo fallback)" })
EOF
" }}}

"
"

" Lualine {{{
lua << EOF
require("lualine").setup({
  options = {
    --theme = 'solarized_dark',
    theme = 'gruvbox',
    icons_enabled = false,
    --theme = "auto",
    -- component_separators = { left = "", right = "" },
    -- section_separators = { left = "", right = "" },
    section_separators = "",
    component_separators = "",
    disabled_filetypes = {},
    always_divide_middle = true,
  },
  sections = {
     lualine_a = {'mode'},
     lualine_b = {''},
     lualine_c = {'filename'},
     lualine_x = {'fileformat', 'filetype'},
     lualine_y = {'progress'},
     lualine_z = {'location'}
    },
})
EOF
" }}}


""}}}

" Plugins Settings {{{
" Startyfy {{{
let g:startify_custom_header = []
" }}}
" Translate {{{
"let g:translate_source = "en" 
let g:translate_target = "uk" 
"let g:translate_popup_window = 1 " if you want use popup window, set value 1 
"let g:translate_winsize = 10 " set buffer window height size if you doesn't use popup window You can also set key mappings. nmap gr <Plug>(Translate)
nmap gr <Plug>(Translate)
vmap t <Plug>(VTranslate)
" }}}
" mundo {{{
set undofile 
set undodir=$HOME/.config/nvim/undo
" }}}
"  some {{{
"
"  }}}
" }}}


" COLORSCHEME {{{
" NeoSolarized {{{
    " Default value is "normal", Setting this option to "high" or "low" does use the
    " same Solarized palette but simply shifts some values up or down in order to
    " expand or compress the tonal range displayed.
"let g:neosolarized_contrast = "normal"

    " Special characters such as trailing whitespace, tabs, newlines, when displayed
    " using ":set list" can be set to one of three levels depending on your needs.
    " Default value is "normal". Provide "high" and "low" options.
"let g:neosolarized_visibility = "normal"

    " I make vertSplitBar a transparent background color. If you like the origin
    " solarized vertSplitBar style more, set this value to 0.
"let g:neosolarized_vertSplitBgTrans = 1

    " If you wish to enable/disable NeoSolarized from displaying bold, underlined
    " or italicized" typefaces, simply assign 1 or 0 to the appropriate variable.
    " Default values:
"let g:neosolarized_bold = 1
"let g:neosolarized_underline = 1
"let g:neosolarized_italic = 1

    " Used to enable/disable "bold as bright" in Neovim terminal. If colors of bold
    " text output by commands like `ls` aren't what you expect, you might want to
    " try disabling this option. Default value:
"let g:neosolarized_termBoldAsBright = 1
"}}}

set termguicolors
set background=dark
" colorscheme NeoSolarized
colorscheme gruvbox8
"}}}

" Statusline {{{
" set statusline= 
" set statusline+=%#PmenuSel# 
" set statusline+=%#LineNr# 
" set statusline+=\ %f 
" set statusline+=%m\ 
" set statusline+=%= 
" set statusline+=%#CursorColumn# 
" set statusline+=\ %y 
" set statusline+=\ %p%% 
" set statusline+=\ %l:%c
"}}}
"
"}}}
"
" File Manager {{{
" You may also like to assign a key to this command:
"
     nnoremap <leader>o :LF<cr>
"

function! LF()
    let temp = tempname()
    exec 'silent !lf -selection-path=' . shellescape(temp)
    if !filereadable(temp)
        redraw!
        return
    endif
    let names = readfile(temp)
    if empty(names)
        redraw!
        return
    endif
    exec 'edit ' . fnameescape(names[0])
    for name in names[1:]
        exec 'argadd ' . fnameescape(name)
    endfor
    redraw!
endfunction
command! -bar LF call LF()
" }}}
"
"```vim
":0put = 'vi: ts=4 sw=4 sts=4 et sr foldmethod=marker foldmarker={{{,}}}'
"```
"
"This sets:
"
"- `ts=4` — tab width
"- `sw=4` — indentation width
"- `sts=4` — soft tab width
"- `et` — expand tabs to spaces
"- `sr` — round indentation to `shiftwidth`
"- `foldmethod=marker` — use fold markers
"- `foldmarker={{{,}}}` — fold marker syntax
" vi: ts=4 sw=4 sts=4 et sr foldmethod=marker foldmarker={{{,}}}

